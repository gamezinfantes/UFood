iTools 2013 Build 1115 Released:
1. The new version is now compatible with iTunes 11.1.3 and iOS 7.0.4
2. Support with iPad Air and new iPad mini
3. Few minor bugs fixed.

iTools 2013 Build 1025 Released:
1. The new version is now compatible with iTunes 11.1.2 and iOS 7.0.3
2. Few minor bugs fixed.
3. A new app store is added.

iTools 2013 Build 0922 Released:
1. Fully supports iOS7
2. Fully supports the brand new iPhone 5s and 5c
3. The new version is now compatible with iTunes 11.1
4. Fixed the bug that the new iTunes might ask you to restore your Apple device if connected with iTools.
5. Fixed the bug that might cause media reloaded when tried to access.
6. Fixed other minor bugs.

iTools 2013 Build 0524 Released:
Fully support iTunes 11.0.3
Optimized the apps manager
Minor Bugs fixed.

iTools 2013 Build 0511 Released:
Fully support iTunes 11
Optimized the apps manager
Minor Bugs fixed.


iTools 2012 Build 1224 Released:
Added the Christmas skin
Added hot features shortcuts on the device Homepage
Fully supports iTunes 11

Ringtone Maker
We have redesigned the ringtone maker. Now, making your own ringtone is much easier in the new version. You can easily and precisely cut a given song.

Contacts
Optimized the work flow of managing contacts, which is more powerful but easier to use.
Merging duplicate contacts is now available in this version. Additionally, you can group contacts in a more natural way.

Photo management
We rethought users how to manage photos on their Apple devices, and then redesigned the photo management feature, which is easier to understand and more efficient to use.

Some of the captions and notes on the interface have been revised for easy understanding.
Minor Bugs fixed.


iTools 2012 Beta 1107 Released: 
Support for iPad Mini, iPad4
Add the guidance of old program cleaning
Optimize the batch operation experience
Improve import photos experience
Improve the program stability and repair some known problems

iTools 2012 Build 1018 Released: 
Fully support iPhone5, iOS6, iTunes 10.7
Better experience for apps installation
Available for change the theme as you like
New photo gallery default browse mode
Better experience for database, add right-click menu, list all related functions
Better experience for detect apps upgrading automatically

iTools 2012 Beta 0913 Released:
Brand new interface with awesome experience.
Multitask mode, allow users to browse other modules when installing Apps or improting files.
iOS6 GM supported
iTunes10.7 supported
App Library optimized:
    New features in displaying supported system versions.
    Add tips to the applications when your system version is too low.
    New features of cleaning up the old version Apps in the library now.
Image Management:
    Quick View mode, to facilitate users quickly browse and zoom.
    New features to classify images based on real-time.
    New features to export images as a directory.
    When importing images, iTools can auto sort by name and time now.
Applications:
    Greatly improve the loading speed of the applications.
Tools Box:
    Add ringtones making function to the tool box
iTools have solve the problem that does not recognize iPod devices.
Bugs fixed
 
iTools 2012 Beta 0329 Released:
Add Media library in the local Library
Add HTTP Proxy in Option
Add Ungrouped in contact, and Up\Down keyboad shortcut
Fix the problem when importing photo
Fix photo viewing problem
Improved importing photo speed
 
iTools 2012 Beta 0216 Released:
1. Add iTunes backup management.
2. Add Time of apps added into iTools app lib. Now can be sorted by time.
3. Optimize FileSystem.
4. Now the Folder can be removed properly from Favorite
5. Add Path to shortcut the location
6. Brand new Plist editor
7. Add tag color
8. Add shortcut key like F5 for refresh, Ctrl+D for export, Ctrl+S for save, Ctrl+Z for reversal.
9. Now music can be sorted by ID3 track No.
10. IOS 4.3.3 SMS restoring won't create new dialog.
11. Optimize Picture loading speed.
12. Solved iTunes incompatible problem.
 
iTools 2011 Beta 1119 Released:
1. Supports devices: iPhone 1,3G,3GS,4,4S iPad 1,2 iPod touch 1,2,3,4
2. Supports iOS versions: iOS 1, 2, 3, 4, 5
3. Works with both Jailbreaked & unJailbreaked devices.
4. Applications management.Supports install, uninstall, backup, update.
5. Media Files management.
a. Supports Music, Video, Ringtone, Podcast, iTunes U, TV Shows Audio books, Music Video & Voice memos
b. Imports & exports media files from computer to devices
c. Transforms mp3 into m4r when drop mp3 files into Ringtone.
d. Transfroms video files into mp4 when drop into Video
e. Searchs lyrics & covers from internet.(iOS 5 not support yet)
f. Plays mp3 files on the device
6. iBooks Supports: Imports and exports PDFs/Epubs.
7. Photos and Ablums management : Imports and exports.
8. Manages docking & desktop by mouse.
a. Smart classify supports automatic classify icons into folders named by system category.
b. Docking & desktop Folders and positions backup and restore.
9. Filesystem managmenets
a. plist file editor
b. Favorite
c. Cydia & installous
d. Storage
10. Personal Information Managments(Contacts, Message, Notes, Safari bookmarks, Callhistory)
a. Imports & exports into csv/outlook
b. Personal inforbackup & restore.
11. System Tools:
a. SSH Tunnel
b. Clean up
c. System logs